
//creem una primera alerta amb una salutació
var salutacio = "Em dic Alba!";
alert (salutacio)

//creem una segona alerta posterior a la primera
var salutacio2= "Sóc el segon script";
alert (salutacio2)
